package com.acme.training.wms.inventory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;

import javax.persistence.LockModeType;
import java.util.Optional;

interface InventoryBalanceRepository extends JpaRepository<InventoryBalance, Long> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<InventoryBalance> findBySkuIdAndWarehouseIdAndLocationId(
            Long skuId, Long warehouseId, Long locationId);
}
