package com.acme.training;

import com.acme.training.platform.error.PlatformException;
import com.acme.training.wms.inventory.InventoryBalanceView;
import com.acme.training.wms.inventory.InventoryCommand;
import com.acme.training.wms.inventory.InventoryCountAdjustmentCommand;
import com.acme.training.wms.inventory.InventoryOperations;
import com.acme.training.wms.inventory.InventoryTransferCommand;
import com.acme.training.wms.inventory.InventoryTransferView;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
class InventoryConcurrencyTest {

    @Autowired
    private InventoryOperations inventory;

    @Autowired
    private PlatformTransactionManager transactionManager;

    @Test
    void ordinaryReadersDoNotBlockEachOtherUntilTransactionCommit() throws Exception {
        asOperator(() -> inventory.receive(new InventoryCommand("reader-initial", "RC-901", 901L, 1L, 1L, 10)));
        ExecutorService workers = Executors.newFixedThreadPool(2);
        CountDownLatch firstRead = new CountDownLatch(1);
        CountDownLatch release = new CountDownLatch(1);
        Future<?> holder = workers.submit(() -> new TransactionTemplate(transactionManager).execute(status -> {
            assertEquals(10, inventory.getBalance(901L, 1L, 1L).getAvailableQuantity());
            firstRead.countDown();
            await(release);
            return null;
        }));
        try {
            assertTrue(firstRead.await(10, TimeUnit.SECONDS), "first reader did not start");
            Future<InventoryBalanceView> reader = workers.submit(() -> inventory.getExistingBalance(901L, 1L, 1L));
            assertEquals(10, reader.get(1, TimeUnit.SECONDS).getAvailableQuantity());
        } finally {
            release.countDown();
            try {
                holder.get(10, TimeUnit.SECONDS);
            } finally {
                workers.shutdownNow();
                assertTrue(workers.awaitTermination(10, TimeUnit.SECONDS), "workers did not stop");
            }
        }
    }

    @Test
    void concurrentReceiveReplaysAfterTheFirstTransactionCommits() throws Exception {
        InventoryCommand command = new InventoryCommand("concurrent-receive", "RC-902", 902L, 1L, 1L, 7);
        InventoryBalanceView replay = overlappingTransactions(() -> inventory.receive(command));
        assertEquals(7, replay.getAvailableQuantity());
        assertEquals(7, inventory.getBalance(902L, 1L, 1L).getAvailableQuantity());
    }

    @Test
    void concurrentTransferReplaysAfterTheFirstTransactionCommits() throws Exception {
        asOperator(() -> inventory.receive(new InventoryCommand("transfer-initial", "RC-903", 903L, 1L, 1L, 10)));
        InventoryTransferCommand command = new InventoryTransferCommand(
                "concurrent-transfer", "TR-903", 903L, 1L, 1L, 2L, 6);
        InventoryTransferView replay = overlappingTransactions(() -> inventory.transfer(command));
        assertEquals(4, replay.getSource().getAvailableQuantity());
        assertEquals(6, replay.getTarget().getAvailableQuantity());
        assertEquals(4, inventory.getBalance(903L, 1L, 1L).getAvailableQuantity());
        assertEquals(6, inventory.getBalance(903L, 1L, 2L).getAvailableQuantity());
    }

    @Test
    void concurrentCountAdjustmentReplaysAfterTheFirstTransactionCommits() throws Exception {
        asOperator(() -> inventory.receive(new InventoryCommand("count-initial", "RC-904", 904L, 1L, 1L, 10)));
        InventoryCountAdjustmentCommand command = new InventoryCountAdjustmentCommand(
                "concurrent-count", "CT-904", 904L, 1L, 1L, 10, 0, 8);
        InventoryBalanceView replay = overlappingTransactions(() -> inventory.adjustFromCount(command));
        assertEquals(8, replay.getAvailableQuantity());
        assertEquals(8, inventory.getBalance(904L, 1L, 1L).getAvailableQuantity());
    }

    @Test
    void countReplayRejectsChangedAbsoluteQuantitiesEvenWhenTheDeltaMatches() throws Exception {
        asOperator(() -> inventory.receive(new InventoryCommand("count-conflict-initial", "RC-905", 905L, 1L, 1L, 10)));
        asOperator(() -> inventory.adjustFromCount(new InventoryCountAdjustmentCommand(
                "count-conflict", "CT-905", 905L, 1L, 1L, 10, 0, 8)));
        PlatformException differentTotals = assertThrows(PlatformException.class, () ->
                asOperator(() -> inventory.adjustFromCount(new InventoryCountAdjustmentCommand(
                        "count-conflict", "CT-905", 905L, 1L, 1L, 11, 0, 9))));
        assertEquals("WMS_IDEMPOTENCY_CONFLICT", differentTotals.getCode());
        PlatformException differentReserved = assertThrows(PlatformException.class, () ->
                asOperator(() -> inventory.adjustFromCount(new InventoryCountAdjustmentCommand(
                        "count-conflict", "CT-905", 905L, 1L, 1L, 10, 1, 8))));
        assertEquals("WMS_IDEMPOTENCY_CONFLICT", differentReserved.getCode());
        assertEquals(8, inventory.getBalance(905L, 1L, 1L).getAvailableQuantity());
    }

    private <T> T overlappingTransactions(Supplier<T> action) throws Exception {
        ExecutorService workers = Executors.newFixedThreadPool(2);
        CountDownLatch firstApplied = new CountDownLatch(1);
        CountDownLatch secondStarted = new CountDownLatch(1);
        CountDownLatch release = new CountDownLatch(1);
        Future<T> first = workers.submit(() -> asOperator(() ->
                new TransactionTemplate(transactionManager).execute(status -> {
                    T result = action.get();
                    firstApplied.countDown();
                    await(release);
                    return result;
                })));
        try {
            assertTrue(firstApplied.await(10, TimeUnit.SECONDS), "first command did not complete");
            Future<T> second = workers.submit(() -> asOperator(() -> {
                secondStarted.countDown();
                return action.get();
            }));
            assertTrue(secondStarted.await(10, TimeUnit.SECONDS), "second command did not start");
            // Hold the first commit while the duplicate enters the public command boundary.
            assertThrows(TimeoutException.class, () -> second.get(1, TimeUnit.SECONDS));
            release.countDown();
            first.get(10, TimeUnit.SECONDS);
            return second.get(10, TimeUnit.SECONDS);
        } finally {
            release.countDown();
            workers.shutdownNow();
            assertTrue(workers.awaitTermination(10, TimeUnit.SECONDS), "workers did not stop");
        }
    }

    private <T> T asOperator(Callable<T> action) throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("X-Operator", "trainer");
        ServletRequestAttributes attributes = new ServletRequestAttributes(request);
        RequestContextHolder.setRequestAttributes(attributes);
        try {
            return action.call();
        } finally {
            attributes.requestCompleted();
            RequestContextHolder.resetRequestAttributes();
        }
    }

    private void await(CountDownLatch latch) {
        try {
            assertTrue(latch.await(10, TimeUnit.SECONDS), "transaction release timed out");
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("test worker interrupted", exception);
        }
    }
}
